import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user:any;books = [];flag:any;bookName : any;item:any;userId:any;
  constructor(private router: Router, private service: BooksService) { 
    this.user = localStorage.getItem("firstName");
    this.userId = localStorage.getItem('userId');
  }
  
  ngOnInit(): void {
    
  }
  
  upload() {
      this.router.navigate(['book']);
  }

  Books(){
    this.service.getBookByName(this.bookName).subscribe((result:any)=>{console.log(result);
      this.books = result;this.flag = 1;
      })
  }
  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}
addToCart(book : any){

  this.item = {cartId : '',bookName: book.bookName,authorName: book.authorName,bookImage: book.bookImage,user : {userId : this.userId}};
  this.service.addToCart1(this.item).subscribe();
}


logout(){
  localStorage.clear();
  this.service.setUserLoggedOut();
}
}
