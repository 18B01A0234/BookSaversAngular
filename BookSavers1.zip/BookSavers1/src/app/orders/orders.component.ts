import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';
var jQuery:any;
@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  userId:any; orders:any;orderId:any;od:any;book :any;flag:any;od1:any;
  constructor(private service:BooksService,private router:Router) { 
    this.userId = localStorage.getItem('userId');
  }

  ngOnInit(): void {
    this.service.getOrderByUserId(this.userId).subscribe((result : any)=>{this.orders = result;});
  }

  details(orderId:any,orderStatus:any,orderDate:any){
    localStorage.setItem('orderId',orderId);
    localStorage.setItem('orderStatus',orderStatus);
    localStorage.setItem('orderDate',orderDate);
    this.router.navigate(['odetails']);
  }
  cancel(orderId : any){

  }

  received(bookId:any){

  }
}
