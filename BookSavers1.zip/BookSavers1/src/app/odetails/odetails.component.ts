import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-odetails',
  templateUrl: './odetails.component.html',
  styleUrls: ['./odetails.component.css']
})
export class OdetailsComponent implements OnInit {

  orderId : any;od:any;orderStatus:any;orderDate:any;
  constructor(private service:BooksService, private router:Router) { 
    this.orderId = localStorage.getItem('orderId');
    this.orderStatus = localStorage.getItem('orderStatus');
    this.orderDate = localStorage.getItem('orderDate');
  }

  ngOnInit(): void {
    this.service.getOdByOrderId(this.orderId).subscribe((result:any)=>{
      this.od = result;
    })
  }

  cancel(orderId : any,bookId:any,bookStatus:any,ruserId : any){
  
    console.log(orderId);
    bookStatus = "On Sale";
    ruserId = 0;
    this.service.updateBook(bookId,bookStatus,ruserId).subscribe();
    this.service.deleteOrder(orderId).subscribe();
    this.router.navigate(['dashboard']);
  }
  recieved(bookId:any,selltype:any,orderStatus:any,orderId:any){
    if(selltype == "Sell"){
      orderStatus = "Delivered";
      this.service.deleteBook(bookId).subscribe();
      this.service.updateOrder(orderId,orderStatus).subscribe();
      this.router.navigate(['dashboard']);
    }else{
      console.log(selltype);
      orderStatus = "Delivered";
      this.service.updateOrder(orderId,orderStatus).subscribe();
      this.router.navigate(['dashboard']);
    }
    
  }

}
