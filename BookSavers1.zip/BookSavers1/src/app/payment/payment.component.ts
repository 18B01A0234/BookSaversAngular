import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
flag:any; user:any;books : any;bookId:any;ruserId:any;bookStatus:any;selltype:any;bookPrice:any;bookName:any;bookImage:any;
orderStatus : any; orderType1 : any;order:any;orderdetails : any;subject :any;body : any;oaddress1 : any;
orderDate1 = new Date(); myDate : any;myDate1 : any; returnDate1 = new Date();flag1: any;

  constructor(private toastr: ToastrService, private router : Router, private service:BooksService) { 
    this.user = JSON.parse(localStorage.getItem('User'));
    this.oaddress1 = this.user.street+ " "+this.user.city+" "+this.user.state;
    this.bookPrice = localStorage.getItem('bookPrice');
    this.bookId = localStorage.getItem('bookId');
    this.ruserId = localStorage.getItem('ruserId');
    this.bookStatus = localStorage.getItem('bookStatus');
    this.selltype = localStorage.getItem('selltype');
    this.bookName = localStorage.getItem('bookName');
    this.bookImage = localStorage.getItem('bookImage');
  }

  ngOnInit(): void {
  }

  showToaster(){
    console.log(this.oaddress1);
    this.toastr.success("Order Placed Successfully");
    setTimeout(() => { this.router.navigate(['dashboard']); }, 2000);

    this.service.getUser(this.ruserId).subscribe((result:any)=>{
      console.log(result.emailId);
      this.subject = "Order Request Accepted";
    this.body = "Hi "+result.firstName+"\nYour order for the book "+ this.bookName+" is successfull, the order is being shipped "+" \n Price of the book: "+this.bookPrice;
      this.service.mail(result.emailId,this.subject,this.body).subscribe();
    });
    
      
  
      if(this.selltype == "sell"){
        this.bookStatus = "Sold";
      this.service.updateBook(this.bookId,this.bookStatus,this.ruserId).subscribe();
        this.orderType1 = "Buy";
      }
      else{
      this.bookStatus = "Not Available";
      this.service.updateBook(this.bookId,this.bookStatus,this.ruserId).subscribe();
        this.orderType1 = "Rent";
      }
    this.myDate = Date.now();
    this.myDate1 = '2000-01-01';
    this.myDate = formatDate(this.myDate,"yyyy-MM-dd",'en-IN');
    this.myDate1 = formatDate(this.myDate1,"yyyy-MM-dd",'en-IN');
    this.orderDate1 = this.myDate;
    console.log(this.orderDate1);
    console.log(this.myDate1);
  
    this.returnDate1 = this.myDate1;
  
    this.service.confirmOrders(this.ruserId,this.returnDate1,this.orderType1,this.oaddress1,this.bookId,this.bookPrice).subscribe();
}

}
