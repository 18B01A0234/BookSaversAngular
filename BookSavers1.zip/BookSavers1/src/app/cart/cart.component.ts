import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  userId:any;cartItems:any;
  constructor(private service: BooksService,private router:Router) { 
    this.userId = localStorage.getItem('userId');
  }

  ngOnInit(): void {
    this.service.getCartItemsListByUserId(this.userId).subscribe((result:any)=>{console.log(result);
      this.cartItems = result;});
  }

  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}
}
