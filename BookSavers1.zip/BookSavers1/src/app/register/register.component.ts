import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: any;
  subject: String;
  body: String;
  constructor(private router:Router, private service: BooksService) {
    this.user = {userId: '', firstName: '', lastName: '', mobile: '', emailId: '', street: '', city : '',state:'', password:''};
    this.subject = "BookSavers Registration";
    this.body = "Thank you for registering to BookSavers. We hope you will enjoy our services";
   }

  ngOnInit(): void {
  }
  
  EnCryptpassword(password : string){
    let encryptedText = this.service.encrypt(password);
    console.log(encryptedText);
    return encryptedText;
    }
    DeCryptpassword(password : string){
    let decryptedText = this.service.decrypt(password);
    console.log(decryptedText);
    return decryptedText;
    }

  register(): void {
    this.user.password = this.EnCryptpassword(this.user.password);
    this.service.registerUser(this.user).subscribe((result: any) => { console.log(result); 
      ;} );
      this.router.navigate(['login'])
    console.log(this.user);
    this.service.mail(this.user.emailId,this.subject,this.body).subscribe();
  }
}
