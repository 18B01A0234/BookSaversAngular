import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';
import { ResourceLoader } from '@angular/compiler';
import { __spreadArrays } from 'tslib';

@Component({
  selector: 'app-show-images',
  templateUrl: './show-images.component.html',
  styleUrls: ['./show-images.component.css']
})
export class ShowImagesComponent implements OnInit {
  books = [];books1 : any;item:any;sbooks:any;sbooks1:any;
  retrivedData : any;i:any;userId:any;flag1 = 0;bn1 = [];
  bookName : any;categoryName:any;flag = 0;bn = [];count = 0;count1 = 0;
  constructor(private router:Router,private service: BooksService) {
    this.userId = localStorage.getItem('userId');
   }

  ngOnInit(): void {
    this.service.getBooks().subscribe( (result: any) => {console.log(result); this.books = result;
      this.sbooks = [];
      for(var i = 0; i < result.length;i++){
        if(result[i].bookStatus == "On Sale"){
          this.count = 0;
          for(var j = 0; j < this.bn.length; j++){
            if(this.bn[j] == result[i].bookName){
              this.count = 1;
              break;
            }
          }
          if(this.count != 1){
            this.sbooks.push(result[i]);
            this.bn.push(result[i].bookName);
          }
          
        }
        if(i == result.length - 1){
          this.flag1 = 1;
        }
      }
    });
  }

  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}
addToCart(book : any){

  this.item = {cartId : '',bookName: book.bookName,authorName: book.authorName,bookImage: book.bookImage,user : {userId : this.userId}};
  this.service.addToCart1(this.item).subscribe();
}

Books(){
  this.service.getBookByCategoryName(this.categoryName).subscribe((result:any)=>{console.log(result);
    this.books1 = result;

    this.sbooks1 = [];
      for(var i = 0; i < result.length;i++){
        if(result[i].bookStatus == "On Sale"){
          this.count1 = 0;
          for(var j = 0; j < this.bn1.length; j++){
            if(this.bn1[j] == result[i].bookName){
              this.count1 = 1;
              break;
            }
          }
          if(this.count1 != 1){
            this.sbooks1.push(result[i]);
            this.bn1.push(result[i].bookName);
          }
          
        }
        if(i == result.length - 1){
          this.flag = 1;
        }
      }
    })
}
}


