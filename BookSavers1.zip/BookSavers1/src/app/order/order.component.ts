import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
})
export class OrderComponent implements OnInit {
  book : any; books = [];books1 = [];userId : any;type1:any;months : any;li1:any;
  flag : any;flag1 : any;emailId: any;li = [];obook : any;user:any;
  book1: any; bookPrice : any;subject : any; body : any;
  bookId : any; obook1 : any;bookStatus:any;ruserId:any;sellers = [];
  
  constructor(private router: Router,private bookService:BooksService) {
    this.book = localStorage.getItem("Books");
    this.userId = localStorage.getItem('userId');
    this.months = 1;
  }

  ngOnInit(): void {
    this.bookService.getBookByName(this.book).subscribe( (result: any) => {console.log(result); this.book1 = result[0];
    this.flag = 1});
  }

  Books(type : any){
    this.type1 = type;
    this.bookService.getBookByColumns(this.book,type).subscribe( (result1: any) => {console.log(result1); this.books1 = result1;
      console.log(this.books1);
      this.sellers = [];
      console.log(type);
      for(var i = 0; i < result1.length; i++){
        if(this.userId != result1[i].user.userId){
          this.sellers.push(result1[i]);
        }
        if(i == result1.length - 1){
          this.flag1 = 1;
        }
      }
      console.log(result1.length);
      console.log(result1[1].user.userId);
      console.log("In Sellers" + this.sellers);
    });
    
  }
  price(value : any){
    this.li = value.split(",");
    console.log(this.li[0]);
    this.bookPrice = this.li[0];
    this.bookId = this.li[1];
    this.emailId = this.li[2];
    
    
    localStorage.setItem('bookId',this.li[1]);
    localStorage.setItem('ruserId',this.userId);
    localStorage.setItem('bookStatus',this.li[3]);
    localStorage.setItem('selltype',this.li[4]);
    localStorage.setItem('bookName',this.li[5]);
    localStorage.setItem('bookImage',this.li[6]);
  }

  order(bookId : any){
    this.li1 = this.li[0] * this.months;
    localStorage.setItem('bookPrice',this.li1);
    this.router.navigate(['payment']);
  }
}
