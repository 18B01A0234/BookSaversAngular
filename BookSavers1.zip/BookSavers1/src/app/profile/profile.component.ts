import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  editedUser:any;decrypt_pass : any;user1:any;user : any;
  password : any; password1 : any;flag : any;
  constructor(private service: BooksService, private toastr: ToastrService) {
    //this.user = JSON.parse(localStorage.getItem('user'));
    
   }

  ngOnInit(): void {
    
    this.user = localStorage.getItem('userId');
    console.log(this.user);
    this.service.getUser(this.user).subscribe( (result: any) => {console.log(result); this.user1 = result; });
  }
  
  pass(password2 : any){
    this.decrypt_pass = this.service.decrypt(this.user1.password);
    console.log(this.decrypt_pass);
    console.log(password2);
    console.log(this.password1);
    if(password2 == this.decrypt_pass){
      this.user1.password = this.service.encrypt(this.password1);
    }
    else{
      alert("Current Password is wrong");
    }
  }

  update(){
    this.service.updateUser(this.user1).subscribe();
  }
  showToaster(){
      this.toastr.success("Updated Successfully!!!!")
  }
  
}
