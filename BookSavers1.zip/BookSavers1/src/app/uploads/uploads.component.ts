import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css'],
})
export class UploadsComponent implements OnInit {
  userId : any; books = [];user : any;bookId: any;emailId : any;
  constructor(private service: BooksService, private router:Router) {
    this.userId = localStorage.getItem('userId');
   }

  ngOnInit(): void {
    this.service.getUser(this.userId).subscribe((result:any)=>{
      this.user = result;
      this.books = this.user.bookList;
    console.log(this.user.bookList);
    })
  }

  
}
