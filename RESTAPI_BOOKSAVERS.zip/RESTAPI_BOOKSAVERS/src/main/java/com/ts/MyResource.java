package com.ts;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.dao.BookDAO;
import com.dao.CartItemsDAO;
import com.dao.OrderDAO;
import com.dao.OrderDetailsDAO;
import com.dao.UserDAO;
import com.db.HibernateTemplate;
import com.dto.Book;
import com.dto.CartItems;
import com.dto.OrderDetails;
import com.dto.Orders;
import com.dto.User;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
	@Path("hi")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hi() throws UnsupportedEncodingException {
		System.out.println("Hi...");
		return "Hi Service!";
	}
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
	@Path("getUserByEmail/{emailId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User getUserByEmail(@PathParam("emailId") String emailId) {
		System.out.println("Recieved path params: "+emailId); 
		UserDAO userDAO = new UserDAO();
		User user = userDAO.getUserByEmail(emailId);
		return user;
	}

	@Path("getUserByUserPass/{loginId}/{password}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User getEmpByUserPass(@PathParam("loginId") String loginId,@PathParam("password") String password) {
		System.out.println("Recieved path params: "+loginId+" "+password); 
		UserDAO userDAO = new UserDAO();
		User user = userDAO.getUserByUserPass(loginId, password);
		return user;
	}


	@Path("getAllUser")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getAllUser() {

		UserDAO userDAO = new UserDAO();
		List <User> userList = userDAO.getAllUsers();

		return userList;
	}
	
	@Path("getUser/{userId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser(@PathParam("userId") int userId) {

		UserDAO userDAO = new UserDAO();
		User user = userDAO.getUser(userId);

		return user;
	}


	@Path("getBooks")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooks() {        
		System.out.println("Inside api get books...");
		BookDAO bookDao = new BookDAO();
		List <Book> bookList = bookDao.getAllBooks();
		return bookList;
	}

	@Path("getBookByName/{bookName}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByName(@PathParam("bookName") String bookName) {        
		System.out.println(bookName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookByName(bookName);
		System.out.println(books); 
		return books;
	}
	
	
	@Path("getBookByCategoryName/{categoryName}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByCategoryName(@PathParam("categoryName") String categoryName) {        
		System.out.println(categoryName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookByCategoryName(categoryName);
		System.out.println(books); 
		return books;
	}
	
	@Path("getBookByColumns/{bookName}/{selltype}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByColumns(@PathParam("bookName") String bookName,@PathParam("selltype") String selltype) {        
		System.out.println(bookName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookByColumns(bookName,selltype);
		System.out.println(books); 
		return books;
	}
	
	@Path("updateBook/{bookId}/{bookStatus}/{ruserId}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateRequestStatus(@PathParam("bookId") int bookId,
	@PathParam("bookStatus") String bookStatus,@PathParam("ruserId") int ruserId) {
	System.out.println("Data Recieved in UpdateBook MYRESOURCE : " + bookStatus + bookId);
	BookDAO bookDao = new BookDAO();
	bookDao.updateBook(bookId,bookStatus,ruserId);
	return "sucess";
	}
	
	@Path("getBookByBookId/{bookId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Book getBookByBookId(@PathParam("bookId") int bookId) {        
		System.out.println(bookId);      
		BookDAO bookDao = new BookDAO();
		Book books = bookDao.getBook(bookId);
		System.out.println(books); 
		return books;
	}
	
	@Path("mail/{emailId}/{subject}/{body}")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String mail(@PathParam("emailId") String emailId,@PathParam("subject") String subject1,@PathParam("body") String body1) throws MessagingException {
			System.out.println(emailId);
			String subject= subject1;
			String body= body1;
			String email= emailId;
			String host = "smtp.gmail.com";
			String from = "soumyaparuchuri2000@gmail.com";
			String pass = "parchuri@412";

			Properties props = System.getProperties();

			props.put("mail.smtp.starttls.enable", "true"); // added this line
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.user", from);
			props.put("mail.smtp.password", pass);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");

			String[] to = {email}; // added this line

			Session session = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			InternetAddress[] toAddress = new InternetAddress[to.length];

			// To get the array of addresses

			for( int i=0; i < to.length; i++ )
			{
				// changed from a while loop
				toAddress[i] = new InternetAddress(to[i]);
			}

			for( int i=0; i < toAddress.length; i++)
			{
				// changed from a while loop
				message.addRecipient(Message.RecipientType.TO, toAddress[i]);
			}

			message.setSubject(subject);
			message.setText(body);

			Transport transport = session.getTransport("smtp");

			transport.connect(host, from, pass);
			transport.sendMessage(message, message.getAllRecipients());

			transport.close();

			return "Successful";
    	}
	
	@Path("registerUser")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void registerUser(User user) {
		System.out.println("Data Recieved in User Register : " + user);
		UserDAO userDao = new UserDAO();
		userDao.register(user);
	
	}
	
	@Path("updateUser")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateUser(User user) {
		System.out.println("Data Recieved in User Update : " + user);
		UserDAO userDao = new UserDAO();
		userDao.updateUser(user);
	
	}
	@Path("registerBook")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerBook(@FormDataParam("bookImage") InputStream fileInputStream, @FormDataParam("bookImage") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("bookName") String bookName,
			@FormDataParam("authorName") String authorName,
			@FormDataParam("bookPrice") Double bookPrice,
			@FormDataParam("categoryName") String categoryName,
			@FormDataParam("selltype") String selltype,
			@FormDataParam("userId") Integer userId,
			@FormDataParam("bookStatus") String bookStatus,
			@FormDataParam("ruserId") int ruserId) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr[] = path.split("/WEB-INF/classes/"); 
			FileOutputStream out = new FileOutputStream(new File(pathArr[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
			while((read = fileInputStream.read(bytes))!= -1){
				out.write(bytes,0,read);
			}
			out.flush();
			out.close();
			User user = new User();
			user.setUserId(userId);
			Book book = new Book();
			book.setBookName(bookName);
			book.setCategoryName(categoryName);
			book.setAuthorName(authorName);
			book.setBookImage(formDataConnectionDisposition.getFileName());
			book.setBookPrice(bookPrice);
			book.setSelltype(selltype);
			book.setUser(user);
			book.setBookStatus(bookStatus);
			book.setRuserId(ruserId);
			System.out.println(user);
			
			
			BookDAO bookDao = new BookDAO();
			bookDao.register(book);
	}
	
	@Path("order")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public String registerOrder(Orders order) {
		System.out.println("Data Recieved in User Register : " + order);
		OrderDAO OrderDao = new OrderDAO();
		OrderDao.register(order);
		String status = "success";
		return status;
	
	}
	
	@Path("orderDetails")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void orderDetails(OrderDetails orderDetails) {
		System.out.println("Data Recieved in orderDetails Register : " + orderDetails);
		OrderDetailsDAO OrderDetailsDao = new OrderDetailsDAO();
		OrderDetailsDao.register(orderDetails);
	}
	
	@Path("getOrderListByUserId/{userId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Orders> getOrderListByUserId(@PathParam("userId") int userId) {        
		System.out.println(userId);      
		OrderDAO ordersDao = new OrderDAO();
		List<Orders> orders = ordersDao.getOrderListByUserId(userId);
		System.out.println(orders); 
		return orders;
	}
	
	@Path("getOdByOrderId/{orderId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public OrderDetails getOdByOrderId(@PathParam("orderId") int orderId) {        
		System.out.println(orderId);      
		OrderDetailsDAO orderDetailsDao = new OrderDetailsDAO();
		OrderDetails orderDetails = orderDetailsDao.getOdByOrderId(orderId);
		return orderDetails;
	}
	

	@POST
	@Path("confirmOrders")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public  void  confirmOrders(@FormDataParam("userId") int userId,
			@FormDataParam("returnDate") Date returnDate,
			@FormDataParam("orderType") String orderType,
			@FormDataParam("oaddress") String oaddress,
			@FormDataParam("bookId") int bookId,
			@FormDataParam("totalPrice") double totalPrice){
		Orders order =null;
		try {
			LocalDate dtf = LocalDate.now();
			LocalTime now = LocalTime.now();
			ObjectMapper objMapper = new ObjectMapper();

			ObjectMapper Mapper = new ObjectMapper();

			order = new Orders();
			order.setOrderType(orderType);
			order.setOaddress(oaddress);
			order.setOrderDate(Date.valueOf(dtf));
			order.setReturnDate(returnDate);
			order.setOrderStatus("Shipping");
			User user = new User();
			user.setUserId(userId); 
			order.setUser(user);
			OrderDAO dao = new OrderDAO();
			dao.register(order);

			List<OrderDetails> ordDetails = new ArrayList<OrderDetails>();
			ObjectMapper obj = new ObjectMapper();
				OrderDetails orderDetails = new OrderDetails();
				Book book = new Book();
				book.setBookId(bookId);
				orderDetails.setBook(book);
				orderDetails.setOrders(order);
				orderDetails.setQuantity(1);
				orderDetails.setTotalPrice(totalPrice);
				OrderDetailsDAO or = new OrderDetailsDAO();
				or.register(orderDetails);
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	@Path("deleteOrder/{orderId}")
	@GET
	@Produces(MediaType.MULTIPART_FORM_DATA)
	public String deleteOrder(@PathParam("orderId") int orderId) {        
		System.out.println(orderId);      
		OrderDAO ordersDao = new OrderDAO();
		ordersDao.deleteOrder(orderId);
		return "success";
	}
	
	@Path("deleteBook/{bookId}")
	@GET
	@Produces(MediaType.MULTIPART_FORM_DATA)
	public String deleteBook(@PathParam("bookId") int bookId) {        
		System.out.println(bookId);      
		BookDAO bookDao = new BookDAO();
		bookDao.deleteBook(bookId);
		return "success";
	}
	
	@Path("updateOrder/{orderId}/{orderStatus}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String updateOrder(@PathParam("orderId") int orderId,@PathParam("orderStatus") String orderStatus) {
	System.out.println("Data Recieved in UpdateOrder MYRESOURCE : " + orderStatus);
	OrderDAO orderDao = new OrderDAO();
	orderDao.updateOrder(orderId,orderStatus);
	return "sucess";
	}
	
	@Path("addToCart")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void registerUser(CartItems item) {
		System.out.println("Data Recieved in User Register : " + item);
		CartItemsDAO cartDao = new CartItemsDAO();
		cartDao.register(item);
	}
	
	@Path("getCartItemsListByUserId/{userId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<CartItems> getCartItemsListByUserId(@PathParam("userId") int userId) {        
		System.out.println(userId);      
		CartItemsDAO cartItemsDao = new CartItemsDAO();
		List<CartItems> items = cartItemsDao.getCartItemsListByUserId(userId);
		System.out.println(items); 
		return items;
	}
	
	/*@Path("registerBook")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void registerBook(Book book) {
		System.out.println("Data Recieved in Book Register : "+book); 
		BookDAO bookDao = new BookDAO();
		bookDao.register(book);
	}
	
	//It is sample code if need to test and insert values into any tables
	/*@Path("registerEmp")
	@GET
	public void registerEmp() {
		DeptDAO deptDao = new DeptDAO();
		
		Department dept = deptDao.getDept(1);
		
		Employee employee = new Employee();
		employee.setEmpName("PASHA");
		employee.setEmail("email@gmail.com");
		employee.setGender("Male");
		employee.setJoinDate(new java.util.Date());
		employee.setDepartment(dept); 
		
		EmployeeDAO employeeDao = new EmployeeDAO();
		employeeDao.register(employee);
	
	}*/
	/*@Path("registerUser1")
	@GET
	public String registerUser1() {
				
		User user = new User();
		user.setUserId(1);
		user.setFirstName("VYSHNAVI");
		user.setLastName("TADIKONDA");
		user.setEmailId("email@gmail.com");
		user.setMobile("7981160809");
		user.setState("AP");
		user.setCity("Gudivada");
		user.setStreet("RajendraNagar");
		
		UserDAO userDao = new UserDAO();
		userDao.register(user);
		
		return "Success";
	
	}
	
	@Path("registerBook1")
	@GET
	public String registerBook1() {
		UserDAO userDao = new UserDAO();
		
		User user = userDao.getUser(1);
		
		Book book = new Book();
		book.setBookName("Financial Managment");
		book.setAuthorName("IM Pandey");
		book.setBookImage("Yes");
		book.setBookPrice(1000.20);
		book.setCategoryName("MBA");
		
		BookDAO bookDao = new BookDAO();
		bookDao.register(book);
		
		return "Success";	
	}*/

}
