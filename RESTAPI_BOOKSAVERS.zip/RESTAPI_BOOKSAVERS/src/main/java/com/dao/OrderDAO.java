package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;
import com.dto.OrderDetails;
import com.dto.Orders;

public class OrderDAO {
	
private SessionFactory factory = null;

	public int register(Orders order) {		
		return HibernateTemplate.addObject(order);
	}
	
	public Orders getOrder(int orderId) {
		return (Orders)HibernateTemplate.getObject(Orders.class,orderId);
	}
	
	public List<Orders> getAllOrders() {
		List<Orders> orders=(List)HibernateTemplate.getObjectListByQuery("From Order");
		return orders;	
	}

	public Orders getOrderById(int userId) {
		return (Orders)HibernateTemplate.getObject(Orders.class,userId);
	}
	
	public List<Orders> getOrderListByUserId(int userId){
		String queryString = "from Orders where userId = :userId";
		return (List)HibernateTemplate.getObjectListByUserId(userId,queryString);
		
	}
	
	public int deleteOrder(int orderId){
		return HibernateTemplate.deleteObject(Orders.class,orderId);
	}
	public int updateOrder(int orderId,String orderStatus){
		 return HibernateTemplate.updateOrder(orderId,orderStatus);
	}
}
