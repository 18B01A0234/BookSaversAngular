package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;
import com.dto.OrderDetails;
import com.dto.Orders;

public class OrderDetailsDAO {
	
	private SessionFactory factory = null;
	
	public int register(OrderDetails orderDetails) {		
		return HibernateTemplate.addObject(orderDetails);
	}
	
	public List<OrderDetails> getAllOrderDetails() {
		List<OrderDetails> orderDetails=(List)HibernateTemplate.getObjectListByQuery("From OrderDetails");
		return orderDetails;	
	}
	
	public OrderDetails getOdByOrderId(int orderId) {
		String queryString = "from OrderDetails where orderId = :orderId";
		return (OrderDetails)HibernateTemplate.getObjectById(orderId,queryString);
	}
}
