package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;
import com.dto.CartItems;
import com.dto.Orders;

public class CartItemsDAO {

	private SessionFactory factory = null;
	
	public int register(CartItems cartItems) {		
		return HibernateTemplate.addObject(cartItems);
	}

	public List<CartItems> getCartItemsListByUserId(int userId){
		String queryString = "from CartItems where userId = :userId";
		return (List)HibernateTemplate.getObjectListByUserId(userId,queryString);
		
	}
}
